package com.example.assignmentnc.hoder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmentnc.R;

public class ListRegisHoder extends RecyclerView.ViewHolder {
    public ImageView imgDelRegis;
    public TextView tvListNameRegis;
    public ListRegisHoder(@NonNull View itemView) {
        super(itemView);
        imgDelRegis= itemView.findViewById(R.id.imgDelRegis);
        tvListNameRegis=itemView.findViewById(R.id.tvListNameRegis);
    }
}
