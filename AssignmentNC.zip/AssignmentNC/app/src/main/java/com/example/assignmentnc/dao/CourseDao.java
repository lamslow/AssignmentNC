package com.example.assignmentnc.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assignmentnc.model.Course;
import com.example.assignmentnc.sqlite.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

import static com.example.assignmentnc.sqlite.DatabaseHelper.C_HOC_PHI;
import static com.example.assignmentnc.sqlite.DatabaseHelper.C_NAME_COURSE;
import static com.example.assignmentnc.sqlite.DatabaseHelper.C_NGAY_BAT_DAU;
import static com.example.assignmentnc.sqlite.DatabaseHelper.C_NGAY_KET_THUC;
import static com.example.assignmentnc.sqlite.DatabaseHelper.T_NAME_COURSE;

public class CourseDao {
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase db;

    public CourseDao(Context context) {
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();
    }

    public long insertCourse(Course course) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_NAME_COURSE, course.nameCourse);
        contentValues.put(C_HOC_PHI, course.hocPhi);
        contentValues.put(C_NGAY_KET_THUC, course.finishCourse);
        contentValues.put(C_NGAY_BAT_DAU, course.startCourse);

        long result = db.insert(T_NAME_COURSE, null, contentValues);
        return result;
    }

    public List<Course> getAllUrser() {
        List<Course> list = new ArrayList<>();
        Cursor cursor = db.query(T_NAME_COURSE, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Course course = new Course();
            course.nameCourse=cursor.getString(0);
            course.startCourse=cursor.getString(1);
            course.finishCourse=cursor.getString(2);
            course.hocPhi=cursor.getString(3);

            list.add(course);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
}
