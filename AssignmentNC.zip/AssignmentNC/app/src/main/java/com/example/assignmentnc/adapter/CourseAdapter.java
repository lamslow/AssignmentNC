package com.example.assignmentnc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmentnc.R;
import com.example.assignmentnc.dao.RegistrationDAO;
import com.example.assignmentnc.hoder.CourseHoder;
import com.example.assignmentnc.model.Course;
import com.example.assignmentnc.model.Registration;

import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseHoder> {
    private Context context;
    private List<Course> list;

    public CourseAdapter(Context context, List<Course> list) {
        this.context = context;
        this.list = list;
    }


    @NonNull
    @Override
    public CourseHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.course, parent, false);
        CourseHoder course = new CourseHoder(view);
        return course;
    }

    @Override
    public void onBindViewHolder(@NonNull CourseHoder holder, final int position) {
        holder.tvNameCourse.setText(list.get(position).nameCourse);
        holder.imgRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View dialogRegis = LayoutInflater.from(context).inflate(R.layout.regis_course, null);
                builder.setView(dialogRegis);
                builder.setTitle("Ban có muốn đăng kí khóa học này không ?");
                final AlertDialog dialog = builder.show();

                Button btnYes=dialogRegis.findViewById(R.id.btnYes);
                Button btnNo=dialogRegis.findViewById(R.id.btnNo);
                 btnNo.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         dialog.dismiss();
                     }
                 });

                 btnYes.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         RegistrationDAO registrationDAO=new RegistrationDAO(context);
                         Registration registration=new Registration();
                         registration.setRegis(list.get(position).nameCourse);
                         boolean result=registrationDAO.insertRegisList(registration);
                         if(result){
                             Toast.makeText(context, "Đăng kí thành công", Toast.LENGTH_SHORT).show();
                             dialog.dismiss();
                         }
                         else {
                             Toast.makeText(context, "Bạn đã đăng kí khóa học này rồi", Toast.LENGTH_SHORT).show();
                             dialog.dismiss();
                         }
                     }
                 });
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View dialogDetail = LayoutInflater.from(context).inflate(R.layout.details, null);
                builder.setView(dialogDetail);
                TextView tvTenKhoaHoc = dialogDetail.findViewById(R.id.tvNameCourse);
                TextView tvNgayBatDau = dialogDetail.findViewById(R.id.tvNgayBatDau);
                TextView tvNgayKetThuc = dialogDetail.findViewById(R.id.tvNgayKetThuc);
                TextView tvHocPhi = dialogDetail.findViewById(R.id.tvHocPhi);

                tvNgayBatDau.setText(list.get(position).startCourse);
                tvNgayKetThuc.setText(list.get(position).finishCourse);
                tvHocPhi.setText(list.get(position).hocPhi);
                tvTenKhoaHoc.setText(list.get(position).nameCourse);
                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
