package com.example.assignmentnc.model;

public class Course {
    public String nameCourse;
    public String startCourse;
    public String finishCourse;
    public String hocPhi;
}
