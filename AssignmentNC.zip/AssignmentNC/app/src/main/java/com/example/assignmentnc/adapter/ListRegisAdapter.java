package com.example.assignmentnc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmentnc.R;
import com.example.assignmentnc.dao.RegistrationDAO;
import com.example.assignmentnc.hoder.ListRegisHoder;
import com.example.assignmentnc.model.Registration;

import java.util.List;

public class ListRegisAdapter extends RecyclerView.Adapter<ListRegisHoder> {
    private Context context;
    private List<Registration> list;
    

    public ListRegisAdapter(Context context, List<Registration> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ListRegisHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.list_regis,parent,false);
        ListRegisHoder listRegisHoder=new ListRegisHoder(view);
        return listRegisHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListRegisHoder holder, final int position) {
        holder.tvListNameRegis.setText(list.get(position).regis);
        holder.imgDelRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameRegis=list.get(position).regis;
                RegistrationDAO registrationDAO=new RegistrationDAO(context);
                int result = registrationDAO.delRegis(nameRegis);
                if(result>0){
                    Toast.makeText(context, "Hủy đăng kí thành công", Toast.LENGTH_SHORT).show();
                    list.remove(position);
                    notifyDataSetChanged();
                }else {
                    Toast.makeText(context, "Hủy đăng kí không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
