package com.example.assignmentnc.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.assignmentnc.R;
import com.example.assignmentnc.adapter.CourseAdapter;
import com.example.assignmentnc.dao.CourseDao;
import com.example.assignmentnc.model.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseActivity extends AppCompatActivity {
    private CourseDao courseDao;
    private RecyclerView rvListCourse;
    private List<Course> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        rvListCourse = findViewById(R.id.rvListCourse);
        setTitle("Đăng kí khóa học");
        list = new ArrayList<>();
        courseDao = new CourseDao(this);
        Course course = new Course();
        course.nameCourse = "Lập trình Android Cơ bản";
        course.startCourse = "1-1-2018";
        course.finishCourse = "1-3-2018";
        course.hocPhi = "1 000 000 VND";
        list.add(course);


        Course course1 = new Course();
        course1.nameCourse = "Lập trình Android Nâng Cao";
        course1.startCourse = "1-1-2018";
        course1.finishCourse = "1-3-2018";
        course1.hocPhi = "1 000 000 VND";
        list.add(course1);


        Course course2 = new Course();
        course2.nameCourse = "Thiết kế giao diện Android";
        course2.startCourse = "1-1-2018";
        course2.finishCourse = "1-3-2018";
        course2.hocPhi = "1 000 000 VND";
        list.add(course2);


        CourseAdapter courseAdapter = new CourseAdapter(this, list);
        rvListCourse.setAdapter(courseAdapter);
        LinearLayoutManager verticle = new LinearLayoutManager(this);
        rvListCourse.setLayoutManager(verticle);
    }

    public void openListRegistration(View view) {
        Intent intent = new Intent(this, ListRegistrationActivity.class);
        startActivity(intent);
    }
}
