package com.example.assignmentnc.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.assignmentnc.R;
import com.example.assignmentnc.adapter.ListRegisAdapter;
import com.example.assignmentnc.dao.RegistrationDAO;
import com.example.assignmentnc.model.Registration;

import java.util.List;

public class ListRegistrationActivity extends AppCompatActivity {

    private List<Registration> list;
    private RegistrationDAO registrationDAO;
    private RecyclerView rvListRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_registration);
        rvListRegis = findViewById(R.id.rvListRegis);
        setTitle("Danh sách đăng kí");
        registrationDAO = new RegistrationDAO(this);
        list = registrationDAO.getAllRegisList();
        ListRegisAdapter listRegisAdapter = new ListRegisAdapter(this, list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rvListRegis.setAdapter(listRegisAdapter);
        rvListRegis.setLayoutManager(linearLayoutManager);

    }
}
