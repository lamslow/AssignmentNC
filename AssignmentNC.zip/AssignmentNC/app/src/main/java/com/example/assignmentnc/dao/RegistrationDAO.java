package com.example.assignmentnc.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.assignmentnc.model.Registration;
import com.example.assignmentnc.sqlite.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class RegistrationDAO {
    public static final String TABLE_NAME_REGIS = "DanhSachDangKi";
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase db;
    public static final String CREATE_TABLE_REGIS = "Create table DanhSachDangKi" +
            "(tenKhoaHocRegis text primary key)";

    public RegistrationDAO(Context context) {
        databaseHelper = new DatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();
    }

    public boolean insertRegisList(Registration registration) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("tenKhoaHocRegis", registration.getRegis());
        long result = db.insert(TABLE_NAME_REGIS, null, contentValues);
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            Log.e("abc", e.toString());
            return false;
        }
        return true;
    }

    public int delRegis(String name) {
        int result = db.delete(TABLE_NAME_REGIS, "tenKhoaHocRegis = ? " , new String[]{name});
        return result;
    }

    public List<Registration> getAllRegisList() {
        List<Registration> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME_REGIS, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Registration registration = new Registration();
            registration.setRegis(cursor.getString(0));

            list.add(registration);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

}
