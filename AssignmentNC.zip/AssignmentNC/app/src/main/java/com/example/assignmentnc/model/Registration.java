package com.example.assignmentnc.model;

public class Registration {
    public String getRegis() {
        return regis;
    }

    public void setRegis(String regis) {
        this.regis = regis;
    }

    public String regis;
}
