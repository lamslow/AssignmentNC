package com.example.assignmentnc.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.assignmentnc.dao.RegistrationDAO;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String CREATE_TABLE="CREATE TABLE Course" +
            "(tenKhoaHoc text primary key,ngayBatDau text" +
            ",ngayKetThuc text,hocPhi text)";
    public static final String T_NAME_COURSE="Course";
    public static final String C_NAME_COURSE="tenKhoaHoc";
    public static final String C_NGAY_BAT_DAU="ngayBatDau";
    public static final String C_NGAY_KET_THUC="ngayKetThuc";
    public static final String C_HOC_PHI="hocPhi";

    public DatabaseHelper(Context context) {
        super(context, "data.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE);
        db.execSQL(RegistrationDAO.CREATE_TABLE_REGIS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
