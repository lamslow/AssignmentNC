package com.example.assignmentnc.hoder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmentnc.R;

public class CourseHoder extends RecyclerView.ViewHolder {
    public TextView tvNameCourse;
    public ImageView imgRegis;
    public CourseHoder(@NonNull View itemView) {
        super(itemView);
        tvNameCourse=itemView.findViewById(R.id.tvNameCourse);
        imgRegis=itemView.findViewById(R.id.imgRegis);
    }
}
